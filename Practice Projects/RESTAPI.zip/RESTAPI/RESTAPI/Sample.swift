//
//  Sample.swift
//  RESTAPI
//
//  Created by admin on 31/01/25.
//

import Foundation

import Combine
let publisher = Just("Hello, Combine!") // Emits a single value
let subscriber = publisher.sink { value in
    print(value) // Prints: Hello, Combine!
}
