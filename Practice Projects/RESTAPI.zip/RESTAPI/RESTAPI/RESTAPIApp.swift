//
//  RESTAPIApp.swift
//  RESTAPI
//
//  Created by admin on 30/01/25.
//

import SwiftUI

@main
struct RESTAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
