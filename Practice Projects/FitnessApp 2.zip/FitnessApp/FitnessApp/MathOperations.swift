//
//  MathOperations.swift
//  FitnessApp
//
//  Created by admin on 01/02/25.
//

import Foundation

public class MathOperations {
    init(){
        print("initializes the maths ops")
    }
    public func add(_ a: Int, _ b: Int) -> Int {
        return a + b
    }

    func subtract(_ a: Int, _ b: Int) -> Int {
        return a - b
    }
}
